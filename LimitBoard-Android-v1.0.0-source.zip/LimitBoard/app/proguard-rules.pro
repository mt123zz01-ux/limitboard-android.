# LimitBoard does not use reflection or a JavaScript bridge.
