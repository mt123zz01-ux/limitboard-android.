(() => {
  const raw = (document.body?.innerText || "")
    .replace(/\u00a0/g, " ")
    .replace(/\r/g, "");
  const lines = raw
    .split("\n")
    .map((line) => line.replace(/\s+/g, " ").trim())
    .filter(Boolean);
  const folded = (value) => (value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
  const all = folded(lines.join(" "));

  const signedOut =
    /\b(log in|sign in)\b/.test(all) ||
    /\b(dang nhap)\b/.test(all) ||
    /log in to get answers/.test(all);

  const percentFrom = (segment) => {
    const patterns = [
      /(?:còn lại|con lai|remaining)\s*:?\s*(\d{1,3})\s*%/i,
      /(\d{1,3})\s*%\s*(?:còn lại|con lai|remaining)/i,
      /(\d{1,3})\s*%/i,
    ];
    for (const pattern of patterns) {
      const match = segment.match(pattern);
      if (match) return Math.max(0, Math.min(100, Number(match[1])));
    }
    return -1;
  };

  const resetFrom = (segment) => {
    const patterns = [
      /(?:đặt lại vào|dat lai vao|resets?(?: on| at)?)\s*:?\s*\|?\s*([^|]{4,80})/i,
    ];
    for (const pattern of patterns) {
      const match = segment.match(pattern);
      if (match) {
        return match[1]
          .split(/(?:tín dụng|tin dung|credits?|usage limit|giới hạn|gioi han)/i)[0]
          .trim()
          .replace(/[.,;]+$/, "");
      }
    }
    return "";
  };

  const section = (markers, stopMarkers) => {
    const index = lines.findIndex((line) => {
      const normalized = folded(line);
      return markers.some((marker) => normalized.includes(marker));
    });
    if (index < 0) return { percent: -1, reset: "" };
    let end = Math.min(lines.length, index + 12);
    for (let cursor = index + 1; cursor < end; cursor++) {
      const normalized = folded(lines[cursor]);
      if (stopMarkers.some((marker) => normalized.includes(marker))) {
        end = cursor;
        break;
      }
    }
    const segment = lines.slice(index, end).join(" | ");
    return {
      percent: percentFrom(segment),
      reset: resetFrom(segment),
    };
  };

  const fiveHourMarkers = [
    "5 gio",
    "five-hour",
    "5-hour",
    "five hour",
  ];
  const weeklyMarkers = [
    "gioi han su dung hang tuan",
    "gioi han hang tuan",
    "weekly usage limit",
    "weekly limit",
  ];
  const creditMarkers = ["tin dung", "credit"];
  const fiveHour = section(fiveHourMarkers, [...weeklyMarkers, ...creditMarkers]);
  const weekly = section(weeklyMarkers, creditMarkers);

  // When the page hides the five-hour meter because the weekly allowance is
  // exhausted, the only visible percentage belongs to the weekly section.
  if (weekly.percent < 0 && /hang tuan|weekly/.test(all)) {
    const weeklyIndex = Math.max(
      all.indexOf("hang tuan"),
      all.indexOf("weekly")
    );
    weekly.percent = percentFrom(all.slice(weeklyIndex, weeklyIndex + 600));
  }

  let credits = -1;
  const creditMatch =
    all.match(/(?:tin dung|credits?)\s*(?:\([^)]*\))?\s*:?\s*(\d[\d.,]*)/) ||
    all.match(/(\d[\d.,]*)\s*(?:tin dung|credits?)/);
  if (creditMatch) {
    credits = Number(creditMatch[1].replace(/[.,]/g, ""));
  }

  let status = "Không đọc được dữ liệu";
  if (signedOut) status = "Cần đăng nhập";
  else if (weekly.percent === 0) status = "Hết limit tuần";
  else if (fiveHour.percent === 0) status = "Hết limit 5 giờ";
  else if (weekly.percent >= 0 || fiveHour.percent >= 0) {
    status = "Còn sử dụng được";
  }

  return JSON.stringify({
    fiveHourPercent: fiveHour.percent,
    weeklyPercent: weekly.percent,
    fiveHourReset: fiveHour.reset,
    weeklyReset: weekly.reset,
    credits,
    signedOut,
    status,
    pageTitle: document.title || "",
    pageUrl: location.href,
  });
})()
