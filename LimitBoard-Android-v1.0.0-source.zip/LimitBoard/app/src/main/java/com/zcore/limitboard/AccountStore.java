package com.zcore.limitboard;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.DateFormat;
import java.util.Date;

final class AccountStore {
    static final int ACCOUNT_COUNT = 6;
    private static final String PREFS = "limitboard_accounts_v1";
    private final SharedPreferences preferences;

    AccountStore(Context context) {
        preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    String getLabel(int index) {
        return preferences.getString(key(index, "label"), "Tài khoản " + (index + 1));
    }

    void setLabel(int index, String label) {
        String cleaned = label == null ? "" : label.trim();
        if (cleaned.isEmpty()) cleaned = "Tài khoản " + (index + 1);
        preferences.edit().putString(key(index, "label"), cleaned).apply();
    }

    UsageSnapshot load(int index) {
        UsageSnapshot snapshot = new UsageSnapshot();
        snapshot.fiveHourPercent = preferences.getInt(key(index, "five_hour"), -1);
        snapshot.weeklyPercent = preferences.getInt(key(index, "weekly"), -1);
        snapshot.credits = preferences.getInt(key(index, "credits"), -1);
        snapshot.fiveHourReset = preferences.getString(key(index, "five_reset"), "");
        snapshot.weeklyReset = preferences.getString(key(index, "weekly_reset"), "");
        snapshot.status = preferences.getString(key(index, "status"), "Chưa có dữ liệu");
        snapshot.updatedAt = preferences.getString(key(index, "updated_at"), "");
        snapshot.signedOut = preferences.getBoolean(key(index, "signed_out"), false);
        return snapshot;
    }

    void saveParsed(int index, UsageSnapshot parsed) {
        SharedPreferences.Editor editor = preferences.edit();
        if (parsed.fiveHourPercent >= 0) {
            editor.putInt(key(index, "five_hour"), UsageSnapshot.clampPercent(parsed.fiveHourPercent));
        }
        if (parsed.weeklyPercent >= 0) {
            editor.putInt(key(index, "weekly"), UsageSnapshot.clampPercent(parsed.weeklyPercent));
        }
        if (parsed.credits >= 0) editor.putInt(key(index, "credits"), parsed.credits);
        if (!parsed.fiveHourReset.isBlank()) {
            editor.putString(key(index, "five_reset"), parsed.fiveHourReset);
        }
        if (!parsed.weeklyReset.isBlank()) {
            editor.putString(key(index, "weekly_reset"), parsed.weeklyReset);
        }
        editor.putBoolean(key(index, "signed_out"), parsed.signedOut);
        editor.putString(key(index, "status"), parsed.status);
        if (parsed.hasAnyLimit()) {
            editor.putString(
                    key(index, "updated_at"),
                    DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                            .format(new Date())
            );
        }
        editor.apply();
    }

    void saveManual(
            int index,
            int fiveHourPercent,
            int weeklyPercent,
            String fiveHourReset,
            String weeklyReset
    ) {
        UsageSnapshot snapshot = new UsageSnapshot();
        snapshot.fiveHourPercent = UsageSnapshot.clampPercent(fiveHourPercent);
        snapshot.weeklyPercent = UsageSnapshot.clampPercent(weeklyPercent);
        snapshot.fiveHourReset = safe(fiveHourReset);
        snapshot.weeklyReset = safe(weeklyReset);
        snapshot.status = statusFor(snapshot);
        snapshot.signedOut = false;
        saveParsed(index, snapshot);
    }

    void markRefreshError(int index, String message) {
        preferences.edit()
                .putString(key(index, "status"), safe(message))
                .apply();
    }

    static String statusFor(UsageSnapshot snapshot) {
        if (snapshot.signedOut) return "Cần đăng nhập";
        if (snapshot.weeklyPercent == 0) return "Hết limit tuần";
        if (snapshot.fiveHourPercent == 0) return "Hết limit 5 giờ";
        if (snapshot.hasAnyLimit()) return "Còn sử dụng được";
        return "Không đọc được dữ liệu";
    }

    private static String safe(String value) {
        return value == null ? "" : value.trim();
    }

    private static String key(int index, String suffix) {
        return "account_" + index + "_" + suffix;
    }
}
