package com.zcore.limitboard;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.io.IOException;

final class MultiAccountRefresher {
    interface Callback {
        void onProgress(int index, String message);
        void onComplete();
    }

    private static final long PAGE_TIMEOUT_MS = 15_000;
    private static final long FIRST_PARSE_DELAY_MS = 2_500;
    private static final long RETRY_DELAY_MS = 2_500;
    private static final int MAX_PARSE_ATTEMPTS = 3;

    private final Activity activity;
    private final FrameLayout host;
    private final AccountStore store;
    private final Callback callback;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final String parserScript;
    private int currentIndex = -1;
    private int parseAttempts;
    private int generation;
    private boolean running;
    private boolean currentFinished;
    private WebView currentWebView;
    private Runnable timeoutRunnable;

    MultiAccountRefresher(
            Activity activity,
            FrameLayout host,
            AccountStore store,
            Callback callback
    ) {
        this.activity = activity;
        this.host = host;
        this.store = store;
        this.callback = callback;
        try {
            this.parserScript = UsageScript.load(activity);
        } catch (IOException error) {
            throw new IllegalStateException("Không tải được usage-parser.js", error);
        }
    }

    boolean isRunning() {
        return running;
    }

    void start() {
        if (running) return;
        running = true;
        currentIndex = -1;
        refreshNext();
    }

    void cancel() {
        running = false;
        generation++;
        handler.removeCallbacksAndMessages(null);
        destroyCurrentWebView();
    }

    private void refreshNext() {
        if (!running) return;
        currentIndex++;
        if (currentIndex >= AccountStore.ACCOUNT_COUNT) {
            running = false;
            destroyCurrentWebView();
            callback.onComplete();
            return;
        }

        callback.onProgress(currentIndex, "đang tải");
        currentFinished = false;
        parseAttempts = 0;
        int thisGeneration = ++generation;

        currentWebView = new WebView(activity);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(1, 1);
        host.addView(currentWebView, params);
        WebViewTools.assignProfile(currentWebView, currentIndex);
        WebViewTools.configure(
                activity,
                currentWebView,
                createClient(thisGeneration),
                new WebChromeClient()
        );

        timeoutRunnable = () -> {
            if (thisGeneration != generation || currentFinished) return;
            store.markRefreshError(currentIndex, "Hết thời gian tải");
            finishCurrent("hết thời gian");
        };
        handler.postDelayed(timeoutRunnable, PAGE_TIMEOUT_MS);
        currentWebView.loadUrl(WebViewTools.USAGE_URL);
    }

    private WebViewClient createClient(int thisGeneration) {
        return new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                callback.onProgress(currentIndex, "đang mở trang Usage");
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (thisGeneration != generation || currentFinished) return;
                handler.postDelayed(
                        () -> attemptParse(thisGeneration),
                        FIRST_PARSE_DELAY_MS
                );
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                if (thisGeneration == generation && !currentFinished) {
                    store.markRefreshError(currentIndex, "WebView bị dừng");
                    finishCurrent("WebView bị dừng");
                }
                return true;
            }
        };
    }

    private void attemptParse(int thisGeneration) {
        if (thisGeneration != generation || currentFinished || currentWebView == null) return;
        parseAttempts++;
        callback.onProgress(currentIndex, "đang đọc limit");
        currentWebView.evaluateJavascript(parserScript, value -> {
            if (thisGeneration != generation || currentFinished) return;
            try {
                UsageSnapshot snapshot = UsageScript.decode(value);
                if (snapshot.hasAnyLimit() || snapshot.signedOut) {
                    store.saveParsed(currentIndex, snapshot);
                    finishCurrent(snapshot.signedOut ? "cần đăng nhập" : "đã cập nhật");
                    return;
                }
            } catch (Exception ignored) {
                // The React page may still be hydrating. Retry below.
            }

            if (parseAttempts < MAX_PARSE_ATTEMPTS) {
                handler.postDelayed(
                        () -> attemptParse(thisGeneration),
                        RETRY_DELAY_MS
                );
            } else {
                store.markRefreshError(currentIndex, "Không đọc được limit");
                finishCurrent("không có dữ liệu");
            }
        });
    }

    private void finishCurrent(String message) {
        if (currentFinished) return;
        currentFinished = true;
        if (timeoutRunnable != null) handler.removeCallbacks(timeoutRunnable);
        callback.onProgress(currentIndex, message);
        destroyCurrentWebView();
        handler.postDelayed(this::refreshNext, 250);
    }

    private void destroyCurrentWebView() {
        if (currentWebView == null) return;
        currentWebView.stopLoading();
        currentWebView.setWebChromeClient(null);
        currentWebView.setWebViewClient(null);
        ViewGroup parent = (ViewGroup) currentWebView.getParent();
        if (parent != null) parent.removeView(currentWebView);
        currentWebView.destroy();
        currentWebView = null;
    }
}
