package com.zcore.limitboard;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

public final class AccountWebActivity extends Activity {
    public static final String EXTRA_ACCOUNT_INDEX = "account_index";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private AccountStore store;
    private WebView webView;
    private ProgressBar progress;
    private TextView hint;
    private int accountIndex;
    private String parserScript;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_web);

        accountIndex = getIntent().getIntExtra(EXTRA_ACCOUNT_INDEX, -1);
        if (accountIndex < 0 || accountIndex >= AccountStore.ACCOUNT_COUNT) {
            finish();
            return;
        }

        if (!WebViewTools.supportsProfiles()) {
            new AlertDialog.Builder(this)
                    .setTitle("WebView chưa hỗ trợ")
                    .setMessage("Hãy cập nhật Chrome và Android System WebView trên Play Store.")
                    .setPositiveButton("Đóng", (dialog, which) -> finish())
                    .setCancelable(false)
                    .show();
            return;
        }

        store = new AccountStore(this);
        webView = findViewById(R.id.webView);
        progress = findViewById(R.id.webProgress);
        hint = findViewById(R.id.txtWebHint);
        TextView title = findViewById(R.id.txtWebTitle);
        Button back = findViewById(R.id.btnBack);
        Button read = findViewById(R.id.btnReadLimit);
        Button clear = findViewById(R.id.btnClearSession);
        title.setText(store.getLabel(accountIndex));

        try {
            parserScript = UsageScript.load(this);
        } catch (IOException error) {
            Toast.makeText(this, "Không tải được bộ đọc limit", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        WebViewTools.assignProfile(webView, accountIndex);
        WebViewTools.configure(
                this,
                webView,
                createWebViewClient(),
                createWebChromeClient()
        );

        back.setOnClickListener(view -> finish());
        read.setOnClickListener(view -> readUsage(true));
        clear.setOnClickListener(view -> confirmClearSession());
        webView.loadUrl(WebViewTools.USAGE_URL);
    }

    private WebViewClient createWebViewClient() {
        return new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progress.setVisibility(View.VISIBLE);
                hint.setText("Đang tải trang…");
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                hint.setText("Đăng nhập đúng tài khoản, mở trang Usage rồi bấm “Đọc limit”.");
                handler.postDelayed(() -> readUsage(false), 2500);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                return uri == null || !"https".equalsIgnoreCase(uri.getScheme());
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                Toast.makeText(
                        AccountWebActivity.this,
                        "WebView đã dừng. Hãy mở lại tài khoản.",
                        Toast.LENGTH_LONG
                ).show();
                finish();
                return true;
            }
        };
    }

    private WebChromeClient createWebChromeClient() {
        return new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        };
    }

    private void readUsage(boolean userInitiated) {
        if (webView == null || parserScript == null) return;
        webView.evaluateJavascript(parserScript, value -> {
            try {
                UsageSnapshot snapshot = UsageScript.decode(value);
                if (snapshot.hasAnyLimit()) {
                    store.saveParsed(accountIndex, snapshot);
                    hint.setText("Đã đọc limit thành công. Bạn có thể quay lại dashboard.");
                    if (userInitiated) {
                        Toast.makeText(this, "Đã cập nhật limit", Toast.LENGTH_SHORT).show();
                    }
                    setResult(RESULT_OK);
                } else if (snapshot.signedOut) {
                    store.saveParsed(accountIndex, snapshot);
                    hint.setText("Tài khoản này chưa đăng nhập.");
                    if (userInitiated) {
                        Toast.makeText(this, "Hãy đăng nhập rồi thử lại", Toast.LENGTH_LONG).show();
                    }
                } else if (userInitiated) {
                    store.markRefreshError(accountIndex, "Không đọc được dữ liệu");
                    Toast.makeText(
                            this,
                            "Chưa thấy limit. Hãy mở Settings → Usage rồi bấm lại.",
                            Toast.LENGTH_LONG
                    ).show();
                }
            } catch (Exception error) {
                if (userInitiated) {
                    Toast.makeText(this, "Trang chưa sẵn sàng, thử lại sau vài giây.", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void confirmClearSession() {
        new AlertDialog.Builder(this)
                .setTitle("Xóa phiên đăng nhập?")
                .setMessage("Chỉ phiên của " + store.getLabel(accountIndex) + " bị xóa.")
                .setPositiveButton("Xóa", (dialog, which) ->
                        WebViewTools.clearProfile(accountIndex, () -> runOnUiThread(() -> {
                            store.markRefreshError(accountIndex, "Cần đăng nhập");
                            webView.loadUrl(WebViewTools.USAGE_URL);
                            Toast.makeText(this, "Đã xóa phiên", Toast.LENGTH_SHORT).show();
                        }))
                )
                .setNegativeButton("Hủy", null)
                .show();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
