package com.zcore.limitboard;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.Profile;
import androidx.webkit.ProfileStore;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

final class WebViewTools {
    static final String USAGE_URL = "https://chatgpt.com/codex/settings/usage";

    private WebViewTools() {}

    static boolean supportsProfiles() {
        return WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE);
    }

    static String profileName(int accountIndex) {
        return "limitboard_account_" + (accountIndex + 1);
    }

    static void assignProfile(WebView webView, int accountIndex) {
        String name = profileName(accountIndex);
        ProfileStore.getInstance().getOrCreateProfile(name);
        WebViewCompat.setProfile(webView, name);
    }

    @SuppressLint("SetJavaScriptEnabled")
    static void configure(
            Context context,
            WebView webView,
            WebViewClient webViewClient,
            WebChromeClient webChromeClient
    ) {
        WebView.setWebContentsDebuggingEnabled(false);
        webView.setBackgroundColor(Color.rgb(11, 18, 32));
        webView.setWebViewClient(webViewClient);
        webView.setWebChromeClient(webChromeClient);
        webView.removeJavascriptInterface("searchBoxJavaBridge_");
        webView.removeJavascriptInterface("accessibility");
        webView.removeJavascriptInterface("accessibilityTraversal");

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setUserAgentString(settings.getUserAgentString() + " LimitBoard/1.0");

        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
    }

    static void clearProfile(int accountIndex, Runnable completed) {
        if (!supportsProfiles()) {
            completed.run();
            return;
        }
        Profile profile = ProfileStore.getInstance().getOrCreateProfile(profileName(accountIndex));
        profile.getCookieManager().removeAllCookies(value -> {
            profile.getCookieManager().flush();
            profile.getWebStorage().deleteAllData();
            completed.run();
        });
    }
}
