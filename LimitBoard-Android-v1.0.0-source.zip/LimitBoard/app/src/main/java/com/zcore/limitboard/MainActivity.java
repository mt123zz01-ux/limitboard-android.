package com.zcore.limitboard;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public final class MainActivity extends Activity {
    private AccountStore store;
    private LinearLayout accountsContainer;
    private Button refreshAllButton;
    private TextView refreshProgress;
    private FrameLayout hiddenWebHost;
    private MultiAccountRefresher refresher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        store = new AccountStore(this);
        accountsContainer = findViewById(R.id.accountsContainer);
        refreshAllButton = findViewById(R.id.btnRefreshAll);
        refreshProgress = findViewById(R.id.txtRefreshProgress);
        hiddenWebHost = findViewById(R.id.hiddenWebHost);

        refreshAllButton.setOnClickListener(view -> refreshAll());
        renderAccounts();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (store != null) renderAccounts();
    }

    @Override
    protected void onDestroy() {
        if (refresher != null) refresher.cancel();
        super.onDestroy();
    }

    private void renderAccounts() {
        accountsContainer.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(this);
        for (int index = 0; index < AccountStore.ACCOUNT_COUNT; index++) {
            final int accountIndex = index;
            View card = inflater.inflate(R.layout.item_account, accountsContainer, false);
            bindCard(card, accountIndex, store.load(accountIndex));
            accountsContainer.addView(card);
        }
    }

    private void bindCard(View card, int index, UsageSnapshot snapshot) {
        TextView name = card.findViewById(R.id.txtAccountName);
        TextView status = card.findViewById(R.id.txtStatus);
        TextView badge = card.findViewById(R.id.txtBadge);
        TextView fivePercent = card.findViewById(R.id.txtFiveHourPercent);
        TextView weeklyPercent = card.findViewById(R.id.txtWeeklyPercent);
        TextView fiveReset = card.findViewById(R.id.txtFiveHourReset);
        TextView weeklyReset = card.findViewById(R.id.txtWeeklyReset);
        TextView updated = card.findViewById(R.id.txtUpdatedAt);
        ProgressBar fiveProgress = card.findViewById(R.id.progressFiveHour);
        ProgressBar weeklyProgress = card.findViewById(R.id.progressWeekly);
        Button open = card.findViewById(R.id.btnOpen);
        Button manual = card.findViewById(R.id.btnManual);
        Button rename = card.findViewById(R.id.btnRename);

        name.setText(store.getLabel(index));
        status.setText(snapshot.status);
        int overall = minimumKnown(snapshot.fiveHourPercent, snapshot.weeklyPercent);
        badge.setText(overall < 0 ? "—" : overall + "%");
        badge.setTextColor(colorFor(overall));

        bindProgress(fiveProgress, fivePercent, snapshot.fiveHourPercent);
        bindProgress(weeklyProgress, weeklyPercent, snapshot.weeklyPercent);
        fiveReset.setText(resetLabel(snapshot.fiveHourReset));
        weeklyReset.setText(resetLabel(snapshot.weeklyReset));
        updated.setText(snapshot.updatedAt.isBlank()
                ? "Chưa cập nhật"
                : "Cập nhật: " + snapshot.updatedAt);

        open.setOnClickListener(view -> openAccount(index));
        manual.setOnClickListener(view -> showManualDialog(index));
        rename.setOnClickListener(view -> showRenameDialog(index));
    }

    private void bindProgress(ProgressBar bar, TextView label, int value) {
        int displayed = value < 0 ? 0 : value;
        bar.setProgress(displayed, false);
        bar.setProgressTintList(ColorStateList.valueOf(colorFor(value)));
        label.setText(value < 0 ? "Chưa rõ" : value + "% còn lại");
        label.setTextColor(colorFor(value));
    }

    private int colorFor(int value) {
        if (value < 0) return getColor(R.color.gray);
        if (value <= 20) return getColor(R.color.red);
        if (value <= 50) return getColor(R.color.yellow);
        return getColor(R.color.green);
    }

    private static int minimumKnown(int first, int second) {
        if (first < 0) return second;
        if (second < 0) return first;
        return Math.min(first, second);
    }

    private static String resetLabel(String reset) {
        return reset == null || reset.isBlank() ? "Chưa rõ thời gian reset" : "Reset: " + reset;
    }

    private void openAccount(int index) {
        if (!WebViewTools.supportsProfiles()) {
            showUnsupportedWebView();
            return;
        }
        Intent intent = new Intent(this, AccountWebActivity.class);
        intent.putExtra(AccountWebActivity.EXTRA_ACCOUNT_INDEX, index);
        startActivity(intent);
    }

    private void refreshAll() {
        if (refresher != null && refresher.isRunning()) return;
        if (!WebViewTools.supportsProfiles()) {
            showUnsupportedWebView();
            return;
        }

        refreshAllButton.setEnabled(false);
        refreshProgress.setVisibility(View.VISIBLE);
        refreshProgress.setText("Đang chuẩn bị…");

        try {
            refresher = new MultiAccountRefresher(
                    this,
                    hiddenWebHost,
                    store,
                    new MultiAccountRefresher.Callback() {
                        @Override
                        public void onProgress(int index, String message) {
                            refreshProgress.setText(String.format(
                                    Locale.getDefault(),
                                    "Tài khoản %d/6 · %s",
                                    index + 1,
                                    message
                            ));
                            renderAccounts();
                        }

                        @Override
                        public void onComplete() {
                            refreshAllButton.setEnabled(true);
                            refreshProgress.setText("Đã cập nhật xong 6 tài khoản");
                            renderAccounts();
                            Toast.makeText(
                                    MainActivity.this,
                                    "Đã cập nhật dashboard",
                                    Toast.LENGTH_SHORT
                            ).show();
                        }
                    }
            );
            refresher.start();
        } catch (IllegalStateException error) {
            refreshAllButton.setEnabled(true);
            refreshProgress.setText("Không khởi động được bộ đọc limit");
            Toast.makeText(this, error.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void showRenameDialog(int index) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(store.getLabel(index));
        input.setSelectAllOnFocus(true);
        input.setTextColor(getColor(R.color.text_primary));
        input.setHintTextColor(getColor(R.color.text_secondary));

        new AlertDialog.Builder(this)
                .setTitle("Đổi tên tài khoản")
                .setView(input)
                .setPositiveButton("Lưu", (dialog, which) -> {
                    store.setLabel(index, input.getText().toString());
                    renderAccounts();
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    private void showManualDialog(int index) {
        UsageSnapshot current = store.load(index);
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        int padding = (int) (20 * getResources().getDisplayMetrics().density);
        form.setPadding(padding, 0, padding, 0);

        EditText five = numericField("Phần trăm 5 giờ (0–100)", current.fiveHourPercent);
        EditText weekly = numericField("Phần trăm tuần (0–100)", current.weeklyPercent);
        EditText fiveReset = textField("Thời gian reset 5 giờ", current.fiveHourReset);
        EditText weeklyReset = textField("Thời gian reset tuần", current.weeklyReset);
        form.addView(five);
        form.addView(weekly);
        form.addView(fiveReset);
        form.addView(weeklyReset);

        new AlertDialog.Builder(this)
                .setTitle("Nhập hạn mức")
                .setView(form)
                .setPositiveButton("Lưu", (dialog, which) -> {
                    int fiveValue = parsePercent(five.getText().toString());
                    int weeklyValue = parsePercent(weekly.getText().toString());
                    store.saveManual(
                            index,
                            fiveValue,
                            weeklyValue,
                            fiveReset.getText().toString(),
                            weeklyReset.getText().toString()
                    );
                    renderAccounts();
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    private EditText numericField(String hint, int value) {
        EditText input = textField(hint, value < 0 ? "" : String.valueOf(value));
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        return input;
    }

    private EditText textField(String hint, String value) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setSingleLine(true);
        input.setText(value == null ? "" : value);
        input.setTextColor(getColor(R.color.text_primary));
        input.setHintTextColor(getColor(R.color.text_secondary));
        return input;
    }

    private static int parsePercent(String raw) {
        try {
            return UsageSnapshot.clampPercent(Integer.parseInt(raw.trim()));
        } catch (Exception ignored) {
            return -1;
        }
    }

    private void showUnsupportedWebView() {
        new AlertDialog.Builder(this)
                .setTitle("WebView chưa hỗ trợ")
                .setMessage(
                        "Điện thoại cần Android System WebView/Chrome mới có tính năng nhiều hồ sơ. " +
                        "Hãy cập nhật Chrome và Android System WebView trên Play Store rồi mở lại app."
                )
                .setPositiveButton("Đã hiểu", null)
                .show();
    }
}
