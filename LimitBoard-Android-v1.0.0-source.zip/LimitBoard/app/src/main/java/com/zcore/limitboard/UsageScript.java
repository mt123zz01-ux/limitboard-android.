package com.zcore.limitboard;

import android.content.Context;

import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

final class UsageScript {
    private static String cached;

    private UsageScript() {}

    static synchronized String load(Context context) throws IOException {
        if (cached != null) return cached;
        StringBuilder builder = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                context.getAssets().open("usage-parser.js"),
                StandardCharsets.UTF_8
        ))) {
            String line;
            while ((line = reader.readLine()) != null) {
                builder.append(line).append('\n');
            }
        }
        cached = builder.toString();
        return cached;
    }

    static UsageSnapshot decode(String evaluateResult) throws Exception {
        if (evaluateResult == null || "null".equals(evaluateResult)) {
            throw new IllegalArgumentException("Trang chưa trả dữ liệu");
        }

        Object first = new JSONTokener(evaluateResult).nextValue();
        JSONObject json;
        if (first instanceof String) {
            json = new JSONObject((String) first);
        } else if (first instanceof JSONObject) {
            json = (JSONObject) first;
        } else {
            throw new IllegalArgumentException("Định dạng kết quả không hợp lệ");
        }

        UsageSnapshot snapshot = new UsageSnapshot();
        snapshot.fiveHourPercent = json.optInt("fiveHourPercent", -1);
        snapshot.weeklyPercent = json.optInt("weeklyPercent", -1);
        snapshot.credits = json.optInt("credits", -1);
        snapshot.fiveHourReset = json.optString("fiveHourReset", "");
        snapshot.weeklyReset = json.optString("weeklyReset", "");
        snapshot.signedOut = json.optBoolean("signedOut", false);
        snapshot.status = json.optString("status", "");
        if (snapshot.status.isBlank()) snapshot.status = AccountStore.statusFor(snapshot);
        return snapshot;
    }
}
