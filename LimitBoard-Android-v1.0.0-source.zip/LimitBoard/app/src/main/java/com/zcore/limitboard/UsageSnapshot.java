package com.zcore.limitboard;

final class UsageSnapshot {
    int fiveHourPercent = -1;
    int weeklyPercent = -1;
    int credits = -1;
    String fiveHourReset = "";
    String weeklyReset = "";
    String status = "Chưa có dữ liệu";
    String updatedAt = "";
    boolean signedOut = false;

    boolean hasAnyLimit() {
        return fiveHourPercent >= 0 || weeklyPercent >= 0;
    }

    static int clampPercent(int value) {
        if (value < 0) return -1;
        return Math.min(100, value);
    }
}
