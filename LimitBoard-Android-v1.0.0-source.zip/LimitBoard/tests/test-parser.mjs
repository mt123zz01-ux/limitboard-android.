import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

const script = fs.readFileSync(
  new URL("../app/src/main/assets/usage-parser.js", import.meta.url),
  "utf8",
);

function parse(body, title = "Usage", href = "https://chatgpt.com/codex/settings/usage") {
  const result = vm.runInNewContext(script, {
    document: {
      body: { innerText: body },
      title,
    },
    location: { href },
  });
  return JSON.parse(result);
}

{
  const result = parse(`
    Hạn mức sử dụng
    Mức sử dụng
    Bạn hiện đã hết lượt sử dụng
    Giới hạn sử dụng hàng tuần
    Còn lại 0%
    Đặt lại vào 30 thg 7, 2026 10:39
    Tín dụng
    0 tín dụng
  `);
  assert.equal(result.fiveHourPercent, -1);
  assert.equal(result.weeklyPercent, 0);
  assert.equal(result.weeklyReset, "30 thg 7, 2026 10:39");
  assert.equal(result.credits, 0);
  assert.equal(result.status, "Hết limit tuần");
}

{
  const result = parse(`
    Usage limits
    5-hour usage limit
    70% remaining
    Resets at Jul 24, 2026 11:00 PM
    Weekly usage limit
    25% remaining
    Resets on Jul 30, 2026 10:39 AM
    Credits
    12 credits
  `);
  assert.equal(result.fiveHourPercent, 70);
  assert.equal(result.fiveHourReset, "Jul 24, 2026 11:00 PM");
  assert.equal(result.weeklyPercent, 25);
  assert.equal(result.weeklyReset, "Jul 30, 2026 10:39 AM");
  assert.equal(result.credits, 12);
  assert.equal(result.status, "Còn sử dụng được");
}

{
  const result = parse(`
    Usage limits
    5-hour usage limit
    Resets at 11:00 PM
    Weekly usage limit
    40% remaining
    Resets Jul 30
  `);
  assert.equal(result.fiveHourPercent, -1);
  assert.equal(result.weeklyPercent, 40);
}

{
  const result = parse("Log in to get answers");
  assert.equal(result.signedOut, true);
  assert.equal(result.status, "Cần đăng nhập");
}

console.log("usage-parser: 4 test cases passed");
