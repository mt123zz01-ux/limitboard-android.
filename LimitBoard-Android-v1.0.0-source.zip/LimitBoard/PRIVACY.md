# Quyền riêng tư

LimitBoard chỉ yêu cầu quyền Internet và trạng thái mạng để mở trang Usage chính thức
của ChatGPT. Mỗi tài khoản nằm trong một hồ sơ WebView riêng.

Ứng dụng không có backend, không gửi cookie, mật khẩu, token, phần trăm hạn mức hoặc
tên tài khoản đến máy chủ của nhà phát triển. Tên thẻ và kết quả đọc được lưu trong
SharedPreferences cục bộ. Xóa dữ liệu ứng dụng trong cài đặt Android sẽ xóa toàn bộ
phiên và dashboard đã lưu.
