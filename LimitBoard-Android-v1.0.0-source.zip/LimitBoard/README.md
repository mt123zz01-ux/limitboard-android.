# LimitBoard

Ứng dụng Android theo dõi hạn mức của 6 tài khoản ChatGPT trên một màn hình.

## Tính năng

- Sáu hồ sơ WebView tách biệt, mỗi hồ sơ giữ phiên đăng nhập của một tài khoản.
- Hai thanh màu cho từng tài khoản: giới hạn 5 giờ và giới hạn hàng tuần.
- Màu xanh khi còn trên 50%, vàng khi còn 21–50%, đỏ khi còn 0–20%.
- Hiện thời gian reset, trạng thái đăng nhập và thời điểm cập nhật gần nhất.
- Nút **Cập nhật tất cả** đọc lần lượt 6 trang Usage.
- Có thể đổi tên tài khoản và nhập số liệu thủ công khi giao diện ChatGPT thay đổi.
- Không có máy chủ trung gian; cookie và mật khẩu không được xuất khỏi vùng dữ liệu ứng dụng.

## Cách dùng

1. Cập nhật Chrome và Android System WebView lên bản mới trên Play Store.
2. Mở LimitBoard, chọn **Mở tài khoản** ở thẻ đầu tiên.
3. Đăng nhập tài khoản ChatGPT thứ nhất và mở trang Usage.
4. Bấm **Đọc limit**, quay lại dashboard rồi làm tương tự cho năm tài khoản còn lại.
5. Sau lần thiết lập đầu, dùng **Cập nhật tất cả** để làm mới cả sáu thẻ.

Nếu đăng nhập Google hoặc Apple bị chặn trong WebView, hãy đăng nhập bằng email/phương
thức khác được ChatGPT cho phép. Không dán cookie hay token vào ứng dụng.

## Phạm vi

LimitBoard chỉ đọc nội dung đang hiển thị trên trang Usage chính thức và lưu kết quả
cục bộ. Ứng dụng không tự chuyển tài khoản để gửi tin nhắn, không tăng hạn mức và
không vượt qua giới hạn dịch vụ. Vì OpenAI không cung cấp API chính thức để đọc hạn
mức của nhiều tài khoản Plus, bộ đọc có thể cần cập nhật nếu giao diện Usage thay đổi.

## Build

Mở thư mục này bằng Android Studio, cài Android SDK 35, sau đó chạy:

```text
Build > Build APK(s)
```

Yêu cầu Android 8.0 trở lên. Tính năng sáu phiên tách biệt còn yêu cầu bản
Chrome/Android System WebView hỗ trợ AndroidX WebKit Multi-Profile.
